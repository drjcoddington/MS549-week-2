
#include <iostream>
#include "functions.h"
using namespace std;

void blastoff(int count)
{
	for (int i = count; i > 0; i--)
	{
		cout << "Countdown " << i << endl;
		system("pause");
	}
}