#pragma once

void blastoff(int count);
void blastoffRec(int count);

