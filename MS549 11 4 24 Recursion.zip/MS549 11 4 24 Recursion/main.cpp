#include <iostream>
#include "functions.h"
using namespace std;

int main()
{
	blastoff(10);
	return 0;
}
