#include <iostream>
#include <time.h>
#include <Windows.h>
#include <chrono>
#include <iomanip>

using namespace std;

int main()
{
	clock_t start, end;
	start = clock();

//code to be timed goes here
	//Sleep(2000);
	end = clock();
	int elapsed = end - start;
	cout << "elapsed time (ms) = " << elapsed;

	auto startHigh = std::chrono::high_resolution_clock::now();
	//cod to be timed goes here

	auto endHigh = std::chrono::high_resolution_clock::now();

	std::chrono::duration<double> elapsed = endHigh - startHigh;

	std::cout << fixed << setprecision(5) << "Operation took " << elapsed.count() << " seconds." << std::endl;


	
}